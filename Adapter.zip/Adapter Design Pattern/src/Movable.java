
public interface Movable {
public double getspeed();
public double getprice();
}
