
public class MovableAdapterImpl implements MovableAdapter {
    public MovableAdapterImpl(Movable luxuryCars) {
		super();
		this.luxuryCars = luxuryCars;
	}

	private Movable luxuryCars;
    
	@Override
	public double getspeed() {
		// TODO Auto-generated method stub
		return convertMPHtoKMPH(luxuryCars.getspeed());
	}

	private double convertMPHtoKMPH(double mph) 
	{
		return mph * 1.60934; 
	}

	@Override
	public double getprice() {
		// TODO Auto-generated method stub
		return convertUSDtoEURO(luxuryCars.getprice());
	}

	private double convertUSDtoEURO(double getspeed) {
		// TODO Auto-generated method stub
		
		return getspeed*0.84;
	}
	 
}
