
public interface MovableAdapter {
    public double getspeed();
    public double getprice();
}
