
public class BugattiVeyron implements Movable {

	
	@Override
	public double getspeed() {
		// TODO Auto-generated method stub
		return 268;
	}

	@Override
	public double getprice() {
		// TODO Auto-generated method stub
		return 1400000;
	}

}
