

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UkClientTest {

	@Test
	public void whenConvertingMPHToKMPH_thenSuccessfullyConverted() {
		Movable bugattiVeyron= new BugattiVeyron(); 
		MovableAdapter bugattiVeyronAdapter=new MovableAdapterImpl( bugattiVeyron);
		assertEquals(bugattiVeyronAdapter.getspeed(), 431.30312, 0.00001);
		
	}

	@Test
	public void whenConvertingUSDToEURO_thenSuccessfullyConverted() {
		Movable bugattiVeyron= new BugattiVeyron(); 
		MovableAdapter bugattiVeyronAdapter=new MovableAdapterImpl( bugattiVeyron);
		
		assertEquals(bugattiVeyronAdapter.getprice(), 1176000, 0.00001);
		
		
	}


}
