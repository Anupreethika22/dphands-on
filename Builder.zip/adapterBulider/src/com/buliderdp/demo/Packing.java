package com.buliderdp.demo;

public interface Packing {
	public String pack();

}
